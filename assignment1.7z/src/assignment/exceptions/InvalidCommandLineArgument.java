package assignment.exceptions;

public class InvalidCommandLineArgument extends RuntimeException {
    public InvalidCommandLineArgument(String message) {
        super(message);
    }

    
}
