package assignment;

class Strings {
    final static String quantity = "quantity";
    final static String type = "type";
    final static String name = "name";
    final static String price = "price";
    final static String raw = "raw";
    final static String imported = "imported";
    final static String manufactured = "manufactured";
}
